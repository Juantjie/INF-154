﻿using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace u25008103_INF154_Practical_2c
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnADD_Click(object sender, EventArgs e)
        {
            string newWord;
            newWord = txtNew.Text;

            lbxLeft.Items.Add(newWord);

            txtNew.Text = "";
            txtNew.Focus();
        }

        private void brnToRight_Click(object sender, EventArgs e)
        {
            string Temp;
            Temp = lbxLeft.Text;
            lbxLeft.Items.Remove(lbxLeft.Text);
            lbxRight.Items.Add(Temp);

            MessageBox.Show("The selected word: " + Temp + " has been transfered successfully.");
        }

        private void btnToLeft_Click(object sender, EventArgs e)
        {
            string Temp;
            Temp = lbxRight.Text;
            lbxRight.Items.Remove(lbxRight.Text);
            lbxLeft.Items.Add(Temp);

            MessageBox.Show("The selected word: " + Temp + " has been transfered successfully.");
        }

        private void btnAddVat_Click(object sender, EventArgs e)
        {
            double VAT, Amount, IncludingVAT;
            VAT = Convert.ToDouble(txtVAT.Text) / 100;
            Amount = Convert.ToDouble(txtAmount.Text);

            IncludingVAT = (VAT * Amount) + Amount;

            MessageBox.Show("The gross price is: R" + Convert.ToString(IncludingVAT));
        }

        private void btnRemove_Click(object sender, EventArgs e)
        {
            
            double VAT, Amount, IncludingVAT;
            VAT = Convert.ToDouble(txtVAT.Text) / 100;
            Amount = Convert.ToDouble(txtAmount.Text);

            IncludingVAT = Amount - (VAT* Amount);

            MessageBox.Show("The net price is: R" + Convert.ToString(IncludingVAT));
        }
}
}
