﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace u25008103_INF154_Practical_4
{
    public partial class frmWaterBill : Form
    {
        public frmWaterBill()
        {
            InitializeComponent();
        }

        private void btnCalculate_Click(object sender, EventArgs e)
        {
            int Units = 0;
            double Total = 0, changeRate = 0, superCharge = 0;

            if (txtCustomerName.Text != "" && int.TryParse(txtWaterUnitsUsed.Text, out Units))
            {
                Units = int.Parse(txtWaterUnitsUsed.Text);

                if (Units >= 0 && Units <= 40)
                {
                    Total = 100;
                    changeRate = 2.50;
                }
                else if (Units >= 41 && Units <= 200)
                {
                    Total = Units * 2.50;
                    changeRate = 2.50;
                }
                else if (Units >= 201 && Units <= 400)
                {
                    Total = Units * 5.00;
                    changeRate = 5.00;
                }
                else if (Units >= 401 && Units <= 600)
                {
                    Total = Units * 7.50;
                    changeRate = 7.50;
                }
                else
                {
                    Total = Units * 10.00;
                    changeRate = 10.00;
                }

                if (Total > 3000)
                {
                    superCharge = Total * 0.14;
                    Total = Total + superCharge;
                }

                rtxtOut.Text = $"Monthly Water Bill \n \n " +
                               $"Customer Name: {txtCustomerName.Text} \n " +
                               $"Units Used: {Units} \n " +
                               $"Change rate: R{changeRate} per unit used \n" +
                               $"Supercharge amount: R{superCharge} \n" +
                               $"Monthly Bill Due: R{Total}";

            }
            else
            {
                MessageBox.Show("Your Name and/or Water Units cannot be empty");
            }
        }
    }
}
