﻿namespace u25008103_INF154_Practical_4
{
    partial class frmWaterBill
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmWaterBill));
            this.lblCustomerName = new System.Windows.Forms.Label();
            this.lblWUU = new System.Windows.Forms.Label();
            this.txtCustomerName = new System.Windows.Forms.TextBox();
            this.txtWaterUnitsUsed = new System.Windows.Forms.TextBox();
            this.rtxtOut = new System.Windows.Forms.RichTextBox();
            this.btnCalculate = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblCustomerName
            // 
            this.lblCustomerName.AutoSize = true;
            this.lblCustomerName.BackColor = System.Drawing.SystemColors.Control;
            this.lblCustomerName.Location = new System.Drawing.Point(83, 102);
            this.lblCustomerName.Name = "lblCustomerName";
            this.lblCustomerName.Size = new System.Drawing.Size(107, 16);
            this.lblCustomerName.TabIndex = 0;
            this.lblCustomerName.Text = "Customer Name:";
            // 
            // lblWUU
            // 
            this.lblWUU.AutoSize = true;
            this.lblWUU.BackColor = System.Drawing.SystemColors.Control;
            this.lblWUU.Location = new System.Drawing.Point(83, 162);
            this.lblWUU.Name = "lblWUU";
            this.lblWUU.Size = new System.Drawing.Size(115, 16);
            this.lblWUU.TabIndex = 1;
            this.lblWUU.Text = "Water Units Used:";
            // 
            // txtCustomerName
            // 
            this.txtCustomerName.Location = new System.Drawing.Point(208, 99);
            this.txtCustomerName.Name = "txtCustomerName";
            this.txtCustomerName.Size = new System.Drawing.Size(158, 22);
            this.txtCustomerName.TabIndex = 2;
            // 
            // txtWaterUnitsUsed
            // 
            this.txtWaterUnitsUsed.Location = new System.Drawing.Point(208, 159);
            this.txtWaterUnitsUsed.Name = "txtWaterUnitsUsed";
            this.txtWaterUnitsUsed.Size = new System.Drawing.Size(158, 22);
            this.txtWaterUnitsUsed.TabIndex = 3;
            // 
            // rtxtOut
            // 
            this.rtxtOut.Location = new System.Drawing.Point(415, 99);
            this.rtxtOut.Name = "rtxtOut";
            this.rtxtOut.Size = new System.Drawing.Size(272, 188);
            this.rtxtOut.TabIndex = 4;
            this.rtxtOut.Text = "";
            // 
            // btnCalculate
            // 
            this.btnCalculate.BackgroundImage = global::u25008103_INF154_Practical_4.Properties.Resources.WaterImage;
            this.btnCalculate.Location = new System.Drawing.Point(208, 264);
            this.btnCalculate.Name = "btnCalculate";
            this.btnCalculate.Size = new System.Drawing.Size(158, 23);
            this.btnCalculate.TabIndex = 5;
            this.btnCalculate.Text = "Calculate";
            this.btnCalculate.UseVisualStyleBackColor = true;
            this.btnCalculate.Click += new System.EventHandler(this.btnCalculate_Click);
            // 
            // frmWaterBill
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlDark;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(800, 367);
            this.Controls.Add(this.btnCalculate);
            this.Controls.Add(this.rtxtOut);
            this.Controls.Add(this.txtWaterUnitsUsed);
            this.Controls.Add(this.txtCustomerName);
            this.Controls.Add(this.lblWUU);
            this.Controls.Add(this.lblCustomerName);
            this.Name = "frmWaterBill";
            this.Text = "Customer Water Bill";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblCustomerName;
        private System.Windows.Forms.Label lblWUU;
        private System.Windows.Forms.TextBox txtCustomerName;
        private System.Windows.Forms.TextBox txtWaterUnitsUsed;
        private System.Windows.Forms.RichTextBox rtxtOut;
        private System.Windows.Forms.Button btnCalculate;
    }
}

