﻿namespace u25008103_INF154_Practical_1
{
    partial class frmGame
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnGoal1 = new System.Windows.Forms.Button();
            this.btnGoal2 = new System.Windows.Forms.Button();
            this.btnReset = new System.Windows.Forms.Button();
            this.btnClose = new System.Windows.Forms.Button();
            this.pnlPlay1 = new System.Windows.Forms.Panel();
            this.pnlPlay2 = new System.Windows.Forms.Panel();
            this.pnlBall = new System.Windows.Forms.Panel();
            this.lblP1Chant = new System.Windows.Forms.Label();
            this.lblP2Chant = new System.Windows.Forms.Label();
            this.lblP1Chant2 = new System.Windows.Forms.Label();
            this.lblP2Chant2 = new System.Windows.Forms.Label();
            this.lblTitle = new System.Windows.Forms.Label();
            this.lblScore = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnGoal1
            // 
            this.btnGoal1.Location = new System.Drawing.Point(191, 417);
            this.btnGoal1.Name = "btnGoal1";
            this.btnGoal1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.btnGoal1.Size = new System.Drawing.Size(75, 23);
            this.btnGoal1.TabIndex = 0;
            this.btnGoal1.Text = "Goal 1";
            this.btnGoal1.UseVisualStyleBackColor = true;
            this.btnGoal1.Click += new System.EventHandler(this.btnGoal1_Click);
            // 
            // btnGoal2
            // 
            this.btnGoal2.Location = new System.Drawing.Point(355, 417);
            this.btnGoal2.Name = "btnGoal2";
            this.btnGoal2.Size = new System.Drawing.Size(75, 23);
            this.btnGoal2.TabIndex = 1;
            this.btnGoal2.Text = "Goal 2";
            this.btnGoal2.UseVisualStyleBackColor = true;
            this.btnGoal2.Click += new System.EventHandler(this.btnGoal2_Click);
            // 
            // btnReset
            // 
            this.btnReset.Location = new System.Drawing.Point(526, 417);
            this.btnReset.Name = "btnReset";
            this.btnReset.Size = new System.Drawing.Size(75, 23);
            this.btnReset.TabIndex = 2;
            this.btnReset.Text = "Reset";
            this.btnReset.UseVisualStyleBackColor = true;
            this.btnReset.Click += new System.EventHandler(this.btnReset_Click);
            // 
            // btnClose
            // 
            this.btnClose.Location = new System.Drawing.Point(355, 472);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(75, 23);
            this.btnClose.TabIndex = 3;
            this.btnClose.Text = "Close";
            this.btnClose.UseVisualStyleBackColor = true;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // pnlPlay1
            // 
            this.pnlPlay1.BackColor = System.Drawing.Color.Green;
            this.pnlPlay1.Location = new System.Drawing.Point(66, 110);
            this.pnlPlay1.Name = "pnlPlay1";
            this.pnlPlay1.Size = new System.Drawing.Size(48, 235);
            this.pnlPlay1.TabIndex = 4;
            // 
            // pnlPlay2
            // 
            this.pnlPlay2.BackColor = System.Drawing.Color.Blue;
            this.pnlPlay2.Location = new System.Drawing.Point(651, 110);
            this.pnlPlay2.Name = "pnlPlay2";
            this.pnlPlay2.Size = new System.Drawing.Size(49, 235);
            this.pnlPlay2.TabIndex = 5;
            // 
            // pnlBall
            // 
            this.pnlBall.BackColor = System.Drawing.SystemColors.ControlLight;
            this.pnlBall.Location = new System.Drawing.Point(373, 210);
            this.pnlBall.Name = "pnlBall";
            this.pnlBall.Size = new System.Drawing.Size(36, 32);
            this.pnlBall.TabIndex = 6;
            // 
            // lblP1Chant
            // 
            this.lblP1Chant.AutoSize = true;
            this.lblP1Chant.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblP1Chant.Location = new System.Drawing.Point(55, 35);
            this.lblP1Chant.Name = "lblP1Chant";
            this.lblP1Chant.Size = new System.Drawing.Size(63, 13);
            this.lblP1Chant.TabIndex = 7;
            this.lblP1Chant.Text = "Shoot Now!";
            // 
            // lblP2Chant
            // 
            this.lblP2Chant.AutoSize = true;
            this.lblP2Chant.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblP2Chant.Location = new System.Drawing.Point(648, 35);
            this.lblP2Chant.Name = "lblP2Chant";
            this.lblP2Chant.Size = new System.Drawing.Size(50, 13);
            this.lblP2Chant.TabIndex = 8;
            this.lblP2Chant.Text = "Defense!";
            // 
            // lblP1Chant2
            // 
            this.lblP1Chant2.AutoSize = true;
            this.lblP1Chant2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblP1Chant2.Location = new System.Drawing.Point(55, 497);
            this.lblP1Chant2.Name = "lblP1Chant2";
            this.lblP1Chant2.Size = new System.Drawing.Size(71, 13);
            this.lblP1Chant2.TabIndex = 9;
            this.lblP1Chant2.Text = "Please score!";
            // 
            // lblP2Chant2
            // 
            this.lblP2Chant2.AutoSize = true;
            this.lblP2Chant2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblP2Chant2.Location = new System.Drawing.Point(648, 497);
            this.lblP2Chant2.Name = "lblP2Chant2";
            this.lblP2Chant2.Size = new System.Drawing.Size(50, 13);
            this.lblP2Chant2.TabIndex = 10;
            this.lblP2Chant2.Text = "Defense!";
            // 
            // lblTitle
            // 
            this.lblTitle.AutoSize = true;
            this.lblTitle.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitle.Location = new System.Drawing.Point(256, 17);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(289, 31);
            this.lblTitle.TabIndex = 11;
            this.lblTitle.Text = "Pong Game Highlight";
            // 
            // lblScore
            // 
            this.lblScore.AutoSize = true;
            this.lblScore.Location = new System.Drawing.Point(336, 48);
            this.lblScore.Name = "lblScore";
            this.lblScore.Size = new System.Drawing.Size(99, 13);
            this.lblScore.TabIndex = 12;
            this.lblScore.Text = "Current Score: 0 - 0";
            // 
            // frmGame
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Gray;
            this.ClientSize = new System.Drawing.Size(800, 568);
            this.Controls.Add(this.lblScore);
            this.Controls.Add(this.lblTitle);
            this.Controls.Add(this.lblP2Chant2);
            this.Controls.Add(this.lblP1Chant2);
            this.Controls.Add(this.lblP2Chant);
            this.Controls.Add(this.lblP1Chant);
            this.Controls.Add(this.pnlBall);
            this.Controls.Add(this.pnlPlay2);
            this.Controls.Add(this.pnlPlay1);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.btnReset);
            this.Controls.Add(this.btnGoal2);
            this.Controls.Add(this.btnGoal1);
            this.Name = "frmGame";
            this.Text = "Game";
            this.Activated += new System.EventHandler(this.frmGame_Activated);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnGoal1;
        private System.Windows.Forms.Button btnGoal2;
        private System.Windows.Forms.Button btnReset;
        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.Panel pnlPlay1;
        private System.Windows.Forms.Panel pnlPlay2;
        private System.Windows.Forms.Panel pnlBall;
        private System.Windows.Forms.Label lblP1Chant;
        private System.Windows.Forms.Label lblP2Chant;
        private System.Windows.Forms.Label lblP1Chant2;
        private System.Windows.Forms.Label lblP2Chant2;
        private System.Windows.Forms.Label lblTitle;
        private System.Windows.Forms.Label lblScore;
    }
}

