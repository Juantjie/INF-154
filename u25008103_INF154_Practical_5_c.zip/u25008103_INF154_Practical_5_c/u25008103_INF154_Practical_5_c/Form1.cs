﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace u25008103_INF154_Practical_5_c
{
    public partial class frmGame : Form
    {
        private Random random = new Random(); // Create a single instance of Random

        public frmGame()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void lblRound_Click(object sender, EventArgs e)
        {

        }

        int round = 0;
        int player1 = 0;
        int player2 = 0;

        private void btnRoll_Click(object sender, EventArgs e)
        {
            int num1 = random.Next(1, 7); // Use the single instance of Random
            lblPlay1.Text = num1.ToString();

            int num2 = random.Next(1, 7); // Use the single instance of Random
            lblPlay2.Text = num2.ToString();

            if (num1 == num2)
            {
                ++round;
                lblUnderSc.Text = "Draw, no one wins this round";
            }
            else if (num1 > num2)
            {
                ++round;
                ++player1;
                lblUnderSc.Text = "Player one wins this round";
            }
            else
            {
                ++round;
                ++player2;
                lblUnderSc.Text = "Player two wins this round";
            }

            lblRound.Text = $"Round {round}";
            lblScore.Text = $"{player1} - {player2}";

            switch (player1)
            {
                case 3:
                    MessageBox.Show("Player one wins the game");
                    lblScore.Text = "0 - 0";
                    lblRound.Text = "Round 0";
                    lblPlay1.Text = "0";
                    lblPlay2.Text = "0";
                    lblUnderSc.Text = "Roll the dice to get started!!!";
                    round = 0;
                    player1 = 0;
                    player2 = 0;
                    break;
            }

            switch (player2)
            {
                case 3:
                    MessageBox.Show("Player two wins the game");
                    lblScore.Text = "0 - 0";
                    lblRound.Text = "Round 0";
                    lblPlay1.Text = "0";
                    lblPlay2.Text = "0";
                    lblUnderSc.Text = "Roll the dice to get started!!!";
                    round = 0;
                    player1 = 0;
                    player2 = 0;
                    break;
            }
        }
    }
}
