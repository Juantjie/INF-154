﻿namespace u25008103_INF154_Practical_5_c
{
    partial class frmGame
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.lblScore = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.lblPlay1 = new System.Windows.Forms.Label();
            this.lblPlay2 = new System.Windows.Forms.Label();
            this.lblRound = new System.Windows.Forms.Label();
            this.lblUnderSc = new System.Windows.Forms.Label();
            this.btnRoll = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(46, 28);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(197, 39);
            this.label1.TabIndex = 0;
            this.label1.Text = "Player One";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // lblScore
            // 
            this.lblScore.AutoSize = true;
            this.lblScore.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblScore.Location = new System.Drawing.Point(305, 62);
            this.lblScore.Name = "lblScore";
            this.lblScore.Size = new System.Drawing.Size(51, 22);
            this.lblScore.TabIndex = 1;
            this.lblScore.Text = "0 - 0";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(442, 28);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(198, 39);
            this.label3.TabIndex = 2;
            this.label3.Text = "Player Two";
            // 
            // lblPlay1
            // 
            this.lblPlay1.AutoSize = true;
            this.lblPlay1.Font = new System.Drawing.Font("Microsoft Sans Serif", 60F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPlay1.Location = new System.Drawing.Point(102, 121);
            this.lblPlay1.Name = "lblPlay1";
            this.lblPlay1.Size = new System.Drawing.Size(83, 91);
            this.lblPlay1.TabIndex = 3;
            this.lblPlay1.Text = "0";
            // 
            // lblPlay2
            // 
            this.lblPlay2.AutoSize = true;
            this.lblPlay2.Font = new System.Drawing.Font("Microsoft Sans Serif", 60F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPlay2.Location = new System.Drawing.Point(497, 121);
            this.lblPlay2.Name = "lblPlay2";
            this.lblPlay2.Size = new System.Drawing.Size(83, 91);
            this.lblPlay2.TabIndex = 4;
            this.lblPlay2.Text = "0";
            // 
            // lblRound
            // 
            this.lblRound.AutoSize = true;
            this.lblRound.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRound.Location = new System.Drawing.Point(290, 155);
            this.lblRound.Name = "lblRound";
            this.lblRound.Size = new System.Drawing.Size(82, 24);
            this.lblRound.TabIndex = 5;
            this.lblRound.Text = "Round 0";
            this.lblRound.Click += new System.EventHandler(this.lblRound_Click);
            // 
            // lblUnderSc
            // 
            this.lblUnderSc.AutoSize = true;
            this.lblUnderSc.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblUnderSc.Location = new System.Drawing.Point(195, 247);
            this.lblUnderSc.Name = "lblUnderSc";
            this.lblUnderSc.Size = new System.Drawing.Size(283, 25);
            this.lblUnderSc.TabIndex = 6;
            this.lblUnderSc.Text = "Roll the dice to get started!!!";
            // 
            // btnRoll
            // 
            this.btnRoll.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRoll.Location = new System.Drawing.Point(279, 284);
            this.btnRoll.Name = "btnRoll";
            this.btnRoll.Size = new System.Drawing.Size(93, 49);
            this.btnRoll.TabIndex = 7;
            this.btnRoll.Text = "Roll Dice";
            this.btnRoll.UseVisualStyleBackColor = true;
            this.btnRoll.Click += new System.EventHandler(this.btnRoll_Click);
            // 
            // frmGame
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(693, 368);
            this.Controls.Add(this.btnRoll);
            this.Controls.Add(this.lblUnderSc);
            this.Controls.Add(this.lblRound);
            this.Controls.Add(this.lblPlay2);
            this.Controls.Add(this.lblPlay1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.lblScore);
            this.Controls.Add(this.label1);
            this.Name = "frmGame";
            this.Text = "Roll the dice game";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblScore;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label lblPlay1;
        private System.Windows.Forms.Label lblPlay2;
        private System.Windows.Forms.Label lblRound;
        private System.Windows.Forms.Label lblUnderSc;
        private System.Windows.Forms.Button btnRoll;
    }
}

